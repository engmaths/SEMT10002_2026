KNN obstacle-avoidance datasets

Files
-----
Nine random-order datasets cover all combinations:
  n = 1,000; 5,000; 20,000
  k = 5; 50; 500

Two additional files provide ordering comparisons for n=5,000, k=50:
  ascending_n5000_k50.csv
  descending_n5000_k50.csv

The corresponding random-order file is:
  random_n5000_k50.csv

Columns
-------
left_cm, centre_cm, right_cm: three distance-sensor readings in centimetres
classification: Clear, Obstacle left, Obstacle ahead, or Obstacle right

For all experiments, use this fixed new observation:
  [50.0, 50.0, 50.0]

Ordering variants
-----------------
The ascending and descending files are ordered by Euclidean distance
from each row's three sensor readings to [50.0, 50.0, 50.0].
The random files contain the same type of observations in shuffled order.

Important experimental note
---------------------------
k is a KNN parameter, not a property of the training data. Therefore,
for a given n, the CSV contents are intentionally identical across the
three k values; the filenames identify the experiment to run. This makes
it easier to compare k values without changing the training observations.

The classification labels are synthetic teaching labels, generated from
the nearest of the three obstacle readings. They are illustrative rather
than a validated robot safety policy.

All data are deterministic and were generated for this exercise.
